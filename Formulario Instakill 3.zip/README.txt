1. Descomprime el RAR en una carpeta

2. Inicia el .exe

3. Rellena el formulario y envíalo



CLAVES: Las claves de inscripción se consiguen en la web "instakilltres.github.io". CADA CLAVE TIENE UN SOLO USO, asi que cuidado con compartirla